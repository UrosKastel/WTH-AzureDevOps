using aspnet_core_dotnet_core.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace aspnet_core_dotnet_core.UnitTests
{
    [TestClass]
    public class SampleUnitTests
    {
        [TestMethod]
        public void IndexPageTest()
        {
            var controller = new HomeController(NullLogger<HomeController>.Instance);
            IActionResult result = controller.Index();
            Assert.AreEqual(null, controller.ViewData["Message"]);
        }

        [TestMethod]
        public void PrivacyPageTest()
        {
            var controller = new HomeController(NullLogger<HomeController>.Instance);
            IActionResult result = controller.Privacy();
            Assert.AreEqual("Use this page to detail your site's privacy policy.", controller.ViewData["Message"]);
        }
    }
}
